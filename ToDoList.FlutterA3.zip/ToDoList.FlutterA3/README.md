

<h1>ToDo-List</h1>

Uma lista de tarefas simples com opções de adicionar, concluir ou remover tarefas. Desafio proposto durante um Workshop com o tema Introdução ao Flutter.
